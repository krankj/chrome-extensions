
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'kjsudi',
  applicationName: 'aws-cron-insert-latest-quote-sg-ce',
  appUid: 'dqrvXvtV1tLNP73Hl3',
  orgUid: 'b690bc0c-44eb-4187-9ae4-6787abc9ba12',
  deploymentUid: 'af37065f-1e04-4be2-a7cd-a770b0b35c37',
  serviceName: 'aws-cron-insert-latest-quote-sg-ce',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.5.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'aws-cron-insert-latest-quote-sg-ce-dev-cronHandler', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.run, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}