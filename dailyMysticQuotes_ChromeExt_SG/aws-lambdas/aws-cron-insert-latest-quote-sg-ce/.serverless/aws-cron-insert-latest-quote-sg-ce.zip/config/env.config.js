module.exports = {
  envVars: {
    SG_PRIVATE_KEY_VAR: "SG_DMQ_CE_PRIVATE_KEY",
    SG_TWITTER_AUTH_KEY_VAR: "SG_DMQ_CE_TWITTER_AUTH_KEY",
  },
};
