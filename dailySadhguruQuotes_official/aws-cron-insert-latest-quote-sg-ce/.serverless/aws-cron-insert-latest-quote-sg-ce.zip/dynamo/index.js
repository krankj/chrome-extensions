const { createTable, deleteTable } = require("./tableOperations");
const { readData, updateData } = require("./dataOperations");

async function callAll() {
  //await createTable();
  //await deleteTable();
  //let updated = await updateData();
}

callAll();
